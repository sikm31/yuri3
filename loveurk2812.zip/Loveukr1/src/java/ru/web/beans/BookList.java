package ru.web.beans;

import java.awt.Image;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import ru.web.db.Database;
import ru.web.db.Database;

public class BookList {

    private ArrayList<Book> bookList = new ArrayList<Book>();

    private ArrayList<Book> getBooks(String str) {

        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = Database.getConnection();

            stmt = conn.createStatement();
            System.out.println(str);
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                  Book book = new Book();
//                book.setId(rs.getLong("id"));
//                book.setName(rs.getString("name"));
//                book.setGenre(rs.getString("genre"));
//                book.setIsbn(rs.getString("isbn"));
//                book.setAuthor(rs.getString("author"));
//                book.setPageCount(rs.getInt("page_count"));
//                book.setPublishDate(rs.getDate("publish_year"));
//                book.setPublisher(rs.getString("publisher"));
//                book.setImage(new ImageIcon(rs.getBytes("image")).getImage());
                  book.setId(rs.getLong("terms.term_id"));
//                System.out.println(rs.getLong("terms.term_id"));
                  book.setName(rs.getString("terms.name"));
//                System.out.println(rs.getLong("terms.name"));
                  book.setPublisher(rs.getString("post_title"));
                  book.setIsbn(rs.getString("post_content").substring(0, 800));
                  book.setPublishDate(rs.getDate("posts.post_date"));
                  book.setPageCount(rs.getInt("object_id"));
                  book.setSlug(rs.getString("terms.slug"));
                  bookList.add(book);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BookList.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(BookList.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(bookList);
        return bookList;
    }

    public ArrayList<Book> getAllBooks() {
        if (!bookList.isEmpty()) {
            return bookList;
        } else {
            return getBooks("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID");
        }
    }

    public ArrayList<Book> getBooksByGenre(long id) {;
        return getBooks("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_type,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID where posts.post_type='post' and terms.term_id="+id/*+" limit 0,7"*/);

    }
}
