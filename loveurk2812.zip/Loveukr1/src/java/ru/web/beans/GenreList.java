package ru.web.beans;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import ru.web.db.Database;
import ru.web.db.Database;

public class GenreList {

    private ArrayList<Genre> genreList = new ArrayList<Genre>();
    private ArrayList<Genre> genreList2 = new ArrayList<Genre>();

    private ArrayList<Genre> getGenres() {
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        Statement stmt2 = null;
        ResultSet rs2 = null;
        Connection conn2 = null;
        try {
            conn = Database.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT terms.term_id,terms.name,terms.slug,taxonomy.description FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id where taxonomy.taxonomy='category' and taxonomy.parent=0 order by name");
            conn2 = Database.getConnection();
            stmt2 = conn.createStatement();
            rs2 = stmt2.executeQuery("SELECT terms.term_id,terms.name,terms.slug,taxonomy.description FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id where taxonomy.taxonomy='category' and taxonomy.parent<>0 order by name");
            while (rs.next()){
                Genre genre = new Genre();
                genre.setName(rs.getString("name"));
                genre.setId(rs.getLong("term_id"));
                genre.setSlug(rs.getString("slug"));
                genreList.add(genre);
                 while (rs2.next()){
                    Genre genre2 = new Genre();
                    genre2.setName(rs2.getString("name"));
                    genre2.setId(rs2.getLong("term_id"));
                    genre2.setSlug(rs2.getString("slug"));
                    genreList.add(genre2);
                 }
            }

        } catch (SQLException ex) {
            Logger.getLogger(GenreList.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(GenreList.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return genreList;

    }

    public ArrayList<Genre> getGenreList() {
        if (!genreList.isEmpty()) {
            return genreList;
        } else {
            return getGenres();
        }
    }
}
