/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.web.beans;

import java.awt.Image;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import ru.web.db.Database;
import ru.web.db.Database;

public class PostList {
    
    private ArrayList<Post> postList = new ArrayList<Post>();

    private ArrayList<Post> getPosts(String str) {

        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = Database.getConnection();

            stmt = conn.createStatement();
            System.out.println(str);
            rs = stmt.executeQuery(str);
            while (rs.next()) {
                  Post post = new Post();
//                book.setId(rs.getLong("id"));
//                book.setName(rs.getString("name"));
//                book.setGenre(rs.getString("genre"));
//                book.setIsbn(rs.getString("isbn"));
//                book.setAuthor(rs.getString("author"));
//                book.setPageCount(rs.getInt("page_count"));
//                book.setPublishDate(rs.getDate("publish_year"));
//                book.setPublisher(rs.getString("publisher"));
//                book.setImage(new ImageIcon(rs.getBytes("image")).getImage());
                  post.setId(rs.getLong("terms.term_id"));
//                System.out.println(rs.getLong("terms.term_id"));
                  post.setName(rs.getString("terms.name"));
//                System.out.println(rs.getLong("terms.name"));
                  post.setPublisher(rs.getString("post_title"));
                  post.setIsbn(rs.getString("post_content"));
                  post.setPublishDate(rs.getDate("posts.post_date"));
                  post.setPageCount(rs.getInt("relation.object_id"));
                  post.setSlug(rs.getString("terms.slug"));
                  postList.add(post);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BookList.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(BookList.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        System.out.println(postList);
        return postList;
    }

    public ArrayList<Post> getAllPosts() {
        if (!postList.isEmpty()) {
            return postList;
        } else {
            return getPosts("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID group by relation.object_id having count(object_id)>0");
        }
    }

    public ArrayList<Post> getPostByGenre(long id) {
        return getPosts("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_type,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID where posts.post_type='post' and relation.object_id="+id+" group by relation.object_id having count(object_id)>0");//"and terms.slug="+"/*+" limit 0,7"*/);

    }
}
