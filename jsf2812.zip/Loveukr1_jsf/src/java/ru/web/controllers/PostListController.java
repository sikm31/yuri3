package ru.web.controllers;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import ru.web.enums.SearchType;
import ru.web.beans.Post;
import ru.web.db.Database;


@ManagedBean(eager = true)
@SessionScoped
//@RequestScoped
//@ApplicationScoped
public class PostListController implements Serializable {

    private boolean requestFromPager;
    private int postOnPage = 7;
    private int selectedMenuId; // выбранный жанр
    private int object_id; //Выбранная статья
    //private char selectedLetter; // выбранная буква алфавита
    private long selectedPageNumber = 1; // выбранный номер страницы в постраничной навигации
    private long totalPostCount; // общее кол-во книг (не на текущей странице, а всего), нажно для постраничности
    private ArrayList<Integer> pageNumbers = new ArrayList<Integer>(); // общее кол-во страниц
    private SearchType searchType;
     private String searchString; // хранит поисковую строку
    private static Map<String, SearchType> searchList = new HashMap<String, SearchType>();
    private ArrayList<Post> currentPostList; // текущий список книг для отображения
    private String currentSql;// последний выполненый sql без добавления limit
    private boolean editMode;
     
   
    public PostListController() {
        fillPostAll();
        ResourceBundle bundle = ResourceBundle.getBundle("ru.web.nls.messages", FacesContext.getCurrentInstance().getViewRoot().getLocale());
       //searchList.put(bundle.getString("author_name"), SearchType.AUTHOR);
        //searchList.put(bundle.getString("book_name"), SearchType.TITLE);
    }

    private void fillPostBySQL(String sql) {
        
        StringBuilder sqlBuilder = new StringBuilder(sql);
        currentSql = sql;
        
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = Database.getConnection();
            stmt = conn.createStatement();
            
            if (!requestFromPager) {
            rs = stmt.executeQuery(sqlBuilder.toString());
            rs.last();
            totalPostCount = rs.getRow();
            
            fillPageNumbers(totalPostCount, postOnPage);
            
            }
            
            if (totalPostCount > postOnPage) {
                sqlBuilder.append(" limit ").append(selectedPageNumber * postOnPage - postOnPage).append(",").append(postOnPage);
            }

            rs = stmt.executeQuery(sqlBuilder.toString());
            
            currentPostList = new ArrayList<Post>();
            System.out.println(sqlBuilder.toString());
            while (rs.next()) {
             Post post = new Post();
             post.setId(rs.getLong("terms.term_id"));
             post.setName(rs.getString("terms.name"));
             post.setTitle(rs.getString("posts.post_title"));
             post.setContent(rs.getString("posts.post_content").substring(0, 800));
             post.setPublishDate(rs.getDate("posts.post_date"));
             post.setIdObj(rs.getLong("relation.object_id"));
             post.setSlug(rs.getString("terms.slug"));
               // System.out.println(post);
             currentPostList.add(post);     
            }
        } catch (SQLException ex) {
            Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    private void fillPostDetailBySQL(String sql) {
        
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        try {
            conn = Database.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            
            currentPostList = new ArrayList<Post>();
            System.out.println(sql);
            while (rs.next()) {
             Post post = new Post();
             post.setId(rs.getLong("terms.term_id"));
             post.setName(rs.getString("terms.name"));
             post.setTitle(rs.getString("posts.post_title"));
             post.setContent(rs.getString("posts.post_content"));//.substring(0, 800));
             post.setPublishDate(rs.getDate("posts.post_date"));
             post.setIdObj(rs.getLong("relation.object_id"));
             post.setSlug(rs.getString("terms.slug"));
               // System.out.println(post);
             currentPostList.add(post);     
            }
        } catch (SQLException ex) {
            Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    private void fillPostAll() {
       fillPostBySQL("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID where posts.post_type='post' group by relation.object_id having count(object_id)>0 order by posts.post_date DESC");
        
    }
    
    private void submitValues(long selectedPageNumber, int selectedMenuId, boolean requestFromPager) {
        this.selectedPageNumber = selectedPageNumber;
        this.selectedMenuId = selectedMenuId;
        this.requestFromPager = requestFromPager;

    }
    
//    private void submitValuesDetail(long selectedPageNumber, int object_id, boolean requestFromPager) {
//        this.selectedPageNumber = selectedPageNumber;
//        this.object_id = object_id;
//        this.requestFromPager = requestFromPager;
//
//    }
      
    public void fillPostByMenu() {
        
        imitateLoading();
        Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        
        selectedMenuId = Integer.valueOf(params.get("term_id"));
        submitValues( 1, selectedMenuId, false);
        fillPostBySQL("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_type,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID where posts.post_type='post' and terms.term_id="+selectedMenuId+" order by posts.post_date DESC");//+" limit 0,7");
        //selectedPageNumber = 1;
        //return "post";
    }
    public void fillPostdetailByPost() {
        Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        Integer object_id = Integer.valueOf(params.get("object_id"));
        //submitValuesDetail( 1, Integer.valueOf(params.get("object_id")), false);
        fillPostDetailBySQL("SELECT terms.term_id,terms.name,terms.slug,taxonomy.taxonomy,taxonomy.description,relation.object_id,posts.post_content,posts.post_title,posts.post_status,posts.post_date,posts.post_type,posts.post_name FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id inner join loveukr.wp_term_relationships as relation on taxonomy.term_taxonomy_id = relation.term_taxonomy_id inner join loveukr.wp_posts as posts on relation.object_id = posts.ID where posts.post_type='post' and relation.object_id="+object_id+" group by relation.object_id having count(object_id)>0 order by posts.post_date DESC");//"and terms.slug="+"/*+" limit 0,7"*/);

    }
    
    public String updatePost() {
        imitateLoading();

        PreparedStatement prepStmt = null;
        ResultSet rs = null;
        Connection conn = null;

        try {
            conn = Database.getConnection();
            prepStmt = conn.prepareStatement("update wp_posts set post_date=?, post_content=?, post_title=? where id=?");


            for (Post post : currentPostList) {
                if (!post.isEdit()) continue;
                prepStmt.setDate(1, (java.sql.Date) post.getPublishDate());
                prepStmt.setString(2, post.getContent());
                prepStmt.setString(3, post.getTitle());
                prepStmt.setLong(4, post.getId());
                prepStmt.addBatch();
            }


            prepStmt.executeBatch();


        } catch (SQLException ex) {
            Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (prepStmt != null) {
                    prepStmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        cancelEdit();
        
        return "post";
    }
    
    

    public boolean isEditMode() {
        return editMode;
    }

    public void showEdit() {
        
        editMode = true;
        
        
        
    }
    
    public void cancelEdit(){
        editMode = false;
        for (Post post : currentPostList) {
            post.setEdit(false);
        }
    }
    
    public void selectPage() {
        Map<String, String> params = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap();
        selectedPageNumber = Integer.valueOf(params.get("page_number"));
        requestFromPager = true;
        fillPostBySQL(currentSql);
        
    }
    
    private void fillPageNumbers(long totalPostCount, int postCountOnPage) {

        int pageCount = totalPostCount > 0 ? (int) (totalPostCount / postCountOnPage) : 0;

        pageNumbers.clear();
        for (int i = 1; i <= pageCount; i++) {
            pageNumbers.add(i);
        }

    }
    
    public ArrayList<Integer> getPageNumbers() {
        return pageNumbers;
    }
    
     public void setPageNumbers(ArrayList<Integer> pageNumbers) {
        this.pageNumbers = pageNumbers;
    }
     
    public String getSearchString() {
        return searchString;
    }

    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }
    
    public SearchType getSearchType() {
        return searchType;
    }

    public void setSearchType(SearchType searchType) {
        this.searchType = searchType;
    }

    public Map<String, SearchType> getSearchList() {
        return searchList;
    }

    public ArrayList<Post> getCurrentPostList() {
        return currentPostList;
    }
     public void setTotalPostCount(long postCount) {
        this.totalPostCount = postCount;
    }

    public long getTotalPostCount() {
        return totalPostCount;
    }

    public int getSelectedMenuId() {
        return selectedMenuId;
    }

    public void setSelectedMenuId(int selectedMenuId) {
        this.selectedMenuId = selectedMenuId;
    }
    
     public int getPostOnPage() {
        return postOnPage;
    }

    public void setPostOnPage(int postOnPage) {
        this.postOnPage = postOnPage;
    }

    public void setSelectedPageNumber(long selectedPageNumber) {
        this.selectedPageNumber = selectedPageNumber;
    }

    public long getSelectedPageNumber() {
        return selectedPageNumber;
    }
    
    private void imitateLoading() {
        try {
            Thread.sleep(5);// имитация загрузки процесса
        } catch (InterruptedException ex) {
            Logger.getLogger(PostListController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

