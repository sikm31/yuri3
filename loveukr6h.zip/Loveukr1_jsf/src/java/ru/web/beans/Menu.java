package ru.web.beans;

public class Menu {
    
    private String term_name;
    private long term_id;
    private String slug;

    public Menu() {
    }

    public Menu(String term_name, long term_id) {
        this.term_name = term_name;
        this.term_id = term_id;
    }

    public long getId() {
        return term_id;
    }

    public void setId(long term_id) {
        this.term_id = term_id;
    }

    

    public String getName() {
        return term_name;
    }

    public void setName(String term_name) {
        this.term_name = term_name;
    }
    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }
    
    

}
