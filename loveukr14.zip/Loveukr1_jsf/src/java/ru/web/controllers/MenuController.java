package ru.web.controllers;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.faces.bean.ApplicationScoped;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import ru.web.db.Database;
import ru.web.beans.Menu;

@ManagedBean(eager = true)
@ApplicationScoped
public class MenuController implements Serializable{ 

    private ArrayList<Menu> menuList = new ArrayList<Menu>();
    //private ArrayList<Menu> menuList2 = new ArrayList<Menu>();
    
    public MenuController(){
        fillMenuAll();
    }

    private void fillMenuAll() {
        Statement stmt = null;
        ResultSet rs = null;
        Connection conn = null;
        Statement stmt2 = null;
        ResultSet rs2 = null;
        Connection conn2 = null;
        menuList = new ArrayList<Menu>();
        try {
            conn = Database.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT terms.term_id,terms.name,terms.slug,taxonomy.description FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id where taxonomy.taxonomy='category' and taxonomy.parent=0 order by name");
            conn2 = Database.getConnection();
            stmt2 = conn.createStatement();
            rs2 = stmt2.executeQuery("SELECT terms.term_id,terms.name,terms.slug,taxonomy.description FROM loveukr.wp_terms as terms inner join loveukr.wp_term_taxonomy as taxonomy on terms.term_id=taxonomy.term_id where taxonomy.taxonomy='category' and taxonomy.parent<>0 order by name");
            while (rs.next()){
                Menu menu = new Menu();
                menu.setName(rs.getString("terms.name"));
                menu.setId(rs.getLong("terms.term_id"));
                menu.setSlug(rs.getString("terms.slug"));
                menuList.add(menu);
//                 while (rs2.next()){
//                    Menu menu2 = new Menu();
//                    menu2.setName(rs2.getString("name"));
//                    menu2.setId(rs2.getLong("term_id"));
//                    menu2.setSlug(rs2.getString("slug"));
//                    menuList.add(menu2);
//                 }
            }

        } catch (SQLException ex) {
            Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (rs != null) {
                    rs.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(MenuController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        

    }

    public ArrayList<Menu> getMenuList() {
       return menuList;
    }
}
