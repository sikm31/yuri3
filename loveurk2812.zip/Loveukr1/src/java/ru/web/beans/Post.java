/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ru.web.beans;



import java.awt.Image;
import java.io.Serializable;
import java.util.Date;

public class Post implements Serializable {
    private long id2;
    private String name2;
    private byte[] content2;
    private int pageCount2;
    private String isbn2;
    private String genre2;
    private String author2;
    private Date publishDate2;
    private String publisher2;
    private Image image2;
    private String slug2;

    public long getId() {
        return id2;
    }

    public void setId(long id2) {
        this.id2 = id2;
    }
   
    public String getName() {
        return name2;
    }

    public void setName(String name2) {
        this.name2 = name2;
    }

    public byte[] getContent() {
        return content2;
    }

    public void setContent(byte[] content2) {
        this.content2 = content2;
    }

    public int getPageCount() {
        return pageCount2;
    }

    public void setPageCount(int pageCount2) {
        this.pageCount2 = pageCount2;
    }

    public String getIsbn() {
        return isbn2;
    }

    public void setIsbn(String isbn2) {
        this.isbn2 = isbn2;
    }

    public String getGenre() {
        return genre2;
    }

    public void setGenre(String genre2) {
        this.genre2 = genre2;
    }

    public String getAuthor() {
        return author2;
    }

    public void setAuthor(String author2) {
        this.author2 = author2;
    }

    public Date getPublishDate() {
        return publishDate2;
    }

    public void setPublishDate(Date publishDate2) {
        this.publishDate2 = publishDate2;
    }

    public String getPublisher() {
        return publisher2;
    }

    public void setPublisher(String publisher2) {
        this.publisher2 = publisher2;
    }

    public Image getImage() {
        return image2;
    }

    public void setImage(Image image2) {
        this.image2 = image2;
    }
    
     public String getSlug() {
        return slug2;
    }

    public void setSlug(String slug2) {
        this.slug2 = slug2;
    }

   
}
