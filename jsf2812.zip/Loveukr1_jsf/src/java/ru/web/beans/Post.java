package ru.web.beans;

import java.awt.Image;
import java.io.Serializable;
import java.util.Date;

public class Post implements Serializable{

    private long term_id;
    private String term_name;
    //private byte[] content;
    private long obj_id;
    private String post_title;
    private String post_content;
   // private String author;
    private Date post_date;
    //private String publisher;
    //private Image image;
    private String slug;
    private boolean edit;

    public long getId() {
        return term_id;
    }

    public void setId(long term_id) {
        this.term_id = term_id;
    }
   
    public String getName() {
        return term_name;
    }

    public void setName(String term_name) {
        this.term_name = term_name;
    }

    public long getIdObj() {
        return obj_id;
    }

    public void setIdObj(long obj_id) {
        this.obj_id = obj_id;
    }

    public String getTitle() {
        return post_title;
    }

    public void setTitle(String post_title) {
        this.post_title = post_title;
    }

    public String getContent() {
        return post_content;
    }

    public void setContent(String post_content) {
        this.post_content = post_content;
    }

//    public String getAuthor() {
//        return author;
//    }
//
//    public void setAuthor(String author) {
//        this.author = author;
//    }

    public Date getPublishDate() {
        return post_date;
    }

    public void setPublishDate(Date post_date) {
        this.post_date = post_date;
    }

//    public String getPublisher() {
//        return publisher;
//    }
//
//    public void setPublisher(String publisher) {
//        this.publisher = publisher;
//    }

     public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }
    
    public boolean isEdit() {
        return edit;
    }

    public void setEdit(boolean edit) {
        this.edit = edit;
    }
    
    
}
