package ru.web.enums;

public enum SearchType {

    AUTHOR,
    TITLE
    
}
